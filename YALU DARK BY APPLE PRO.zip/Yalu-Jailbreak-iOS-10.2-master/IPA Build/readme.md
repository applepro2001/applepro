This is the IPA of my Yalu JAilbreak Fork (Yalu Dark).

* IPA can be installed with Cydia Impactor (Windows, OS X, Linux): http://www.cydiaimpactor.com/
* Updated to reflect Beta 7
* IPA's HASH: ed2560dadd4c4b7b47e6bd989e3567029099c4f9

Not required to check the SHA-1 hash, but highly recommended to prevent downloading corrupted, tampered files. ONLY download my Yalu Dark IPAs from THIS Git! I never host them anywhere else.

Key things to keep in mind:

* iPAs are precompiled from the same source-code available on my Git
* I only host Yalu DARK on this GitHub
* Hotlinking is NOT allowed
* You should be cautious from where you get IPAs especially if the source code is not provided, Yalu is not a toy, a malicious person can easily compile a malware IPA that uses Yalu's exploits, so always check the hashes, check the sources and AVOID IPA STORES AT ALL COSTS!

~GeoSn0w

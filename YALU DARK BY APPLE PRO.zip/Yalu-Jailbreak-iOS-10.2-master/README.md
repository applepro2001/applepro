# Yalu-Jailbreak-iOS-10.2
This is GeoSn0w (F.C.E. 365 TV)'s Yalu Jailbreak fork.
My own fork of Yalu Jailbreak for iOS 10.0 to 10.2 by qwertyoruiopz with support for iPhone 6/ 5S and iPod Touch 6, Dark UI and certification status.
I've decided to make this as Luca added support for iPhone 6 (7,2) on the project, but not on the compiled IPA, so while I was at it, I also decided to play a bit with the project and I added some extra features.

<img src="https://cloud.githubusercontent.com/assets/15067741/23566184/85b53b60-0059-11e7-85db-4e3938a1bad7.PNG" width="250" height= "450">
<img src="https://cloud.githubusercontent.com/assets/15067741/23566186/869151cc-0059-11e7-9cf1-93e7c4f068f2.PNG" width="250" height= "450">
<img src="https://cloud.githubusercontent.com/assets/15067741/23566482/b8f572e6-005a-11e7-832e-e1d6f4e00306.PNG" width="250" height= "450">

Changes:
* Dark User Interface
* Shows how many days out of the 7 Apple gives you have passed, brings a warning to resign it on day 6.
* iOS Version Detection
* IPA Support (Reflects Yalu Beta 7)
* This is a Beta Jailbreak, use at your own risk!
* Supports ALL 64-Bit Devices (from iPhone 5S to iPhone 6S Plus) 
* iPhone 7 is only supported up to 10.1.1 (If on 10.2, don't update to 10.2.1!) on Beta 3

* [!] The SHA SUM OF THE IPA: ed2560dadd4c4b7b47e6bd989e3567029099c4f9 (Not required to be verified, but highly recommended)
* [!] Rename yalu102.xcodeproj.zip to yalu102.xcodeproj if you want to use the source code!


Feel free to play with project as you want. Luca Todesco licensed it under WTFPL (Do What The Fuck You Want To Public License)
This is not the original Yalu iOS 10.2 Project.
Check out the original project: https://github.com/kpwn/yalu102 for updates.

* My Channel: https://youtube.com/c/fce365official
* My Twitter: https://twitter.com/FCE365
* My Website: https://fce365.info
* SubReddit: https://reddit.com/r/idevicecentral/


